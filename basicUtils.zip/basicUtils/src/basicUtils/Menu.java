package basicUtils;

import java.util.Scanner;


	public class Menu  {
		
		static Scanner scanner = new Scanner(System.in);
	
	public Menu() {}

	
	public static void main(String[] args) {
		
		System.out.println("Please chose an option:");
		System.out.println("1.-Basic calculator.");
		System.out.println("2.-Encoder.");
		System.out.println("3.-Student average calculator.");
		int option = scanner.nextInt();
		
		
		switch(option) {
		case 1:
				calculator();
			break;
		case 2:
				encoder();
			break;
		case 3:
				avrgCalc();
			break;
		default:{System.out.println("***Please enter a valid option***");
				System.out.println();
				main(args);}
		
		}//switch-case
		
	}//main
	
	
	public static void calculator() {
		
		CalculatorInterface cal = new Calculator();
		
		System.out.println("Please chose an option:");
		System.out.println("1.-Sum (a + b)");
		System.out.println("2.-Substract (a - b)");
		System.out.println("3.-Multiply (a x b)");
		System.out.println("4.-Divide (a / b)");
		int option = scanner.nextInt();
		
		switch(option) {
		case 1:
				cal.add();
			break;
		case 2:
				cal.sus(); 
			break;
		case 3:
				cal.mult(); 
			break;
		case 4:
				cal.div();
		break;
		default:{ System.out.println("***Please enter a valid option***");
				System.out.println();
				calculator();
		}
		
		
		}//switch-case
	}// calculator()

	public static void encoder() {
		
		Encoder enc = new Encoder();
		
		System.out.println("Please chose an option:");
		System.out.println("1.-Encode a String to Base64.");
		System.out.println("2.-Decode a Base64 to String.");
		int option = scanner.nextInt();
		
		switch(option) {
		case 1:
				enc.encode();
			break;
		case 2:
				enc.decode();
			break;
		default:{ System.out.println("***Please enter a valid option***");
				System.out.println();
				encoder();
			}//default
		}//switch-case	
	}//encoder()
	
	public static void avrgCalc() {
		AvrgCalculator ac = new AvrgCalculator();
		ac.exe();
	}//avrgCalc()
	
}//class
