package basicUtils;

public interface CalculatorInterface {
	
	 void add ();
	 void sus();
	 void mult();
	 void div(); 
	 double val(String input);

}
