package basicUtils;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Calculator implements CalculatorInterface {

	static Menu menu = new Menu();
	public Calculator() {
		
	}

	Scanner scanner = new Scanner(System.in);
	
	@Override
	public void add() {
		System.out.println("Please enter the value for a:");
		double a = val(scanner.nextLine());
		System.out.println("Please enter the value for b:");
		double b = val(scanner.nextLine());
		
		System.out.println("The result is: "+(a+b));
	}

	@Override
	public void sus() {
		System.out.println("Please enter the value for a:");
		double a = val(scanner.nextLine());
		System.out.println("Please enter the value for b:");
		double b = val(scanner.nextLine());
		
		System.out.println("The result is: "+(a-b));
		
	}

	@Override
	public void mult() {
		System.out.println("Please enter the value for a:");
		double a = val(scanner.nextLine());
		System.out.println("Please enter the value for b:");
		double b = val(scanner.nextLine());
		System.out.println("The result is: "+(a*b));
	}

	@Override
	public void div() {
		try {
			System.out.println("Please enter the value for a:");
			double a = val(scanner.nextLine());
			System.out.println("Please enter the value for b:");
			double b = val(scanner.nextLine());
			
			if (b == 0) {
	            throw new IllegalArgumentException("Can´t divide by 0");
	        }
			System.out.println("The result is: "+(a/b));
		}
		catch (IllegalArgumentException e) {
            System.out.println("Error: You are dividing by 0.");
            menu.main(null);
        }
		
	}

	
	 @Override
	 public  double val(String input) {
	 
	 String Spaces = input.replace(" ", "");
	 double noSpaces =0.0;
	
	 		if(!Spaces.matches(".*[^0-9.\\+\\-].*")){
		        try {
		        	
		            // Convert to double
		            noSpaces = Double.parseDouble(Spaces);
		            
		            // Check if the number is within range
		            if (noSpaces >= -Double.MAX_VALUE && noSpaces <= Double.MAX_VALUE ) {
		            	
		            } 
		            else {
		                System.out.println("Number out of range.\n");
		                menu.main(null);
		            }
		        }
		        catch (NumberFormatException e) {
		            System.out.println("**********Error: Please enter a valid number.\n");
		         menu.main(null);
		        }
		    } 
		    else {
		        System.out.println("**********Error: Please enter a valid number.\n");
		            menu.main(null);
		        }
	        
	return noSpaces;
	
	}//val()
	 

}//class
