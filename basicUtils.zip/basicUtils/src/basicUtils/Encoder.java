package basicUtils;

import java.util.Base64;
import java.util.Scanner;

public class Encoder {

	static Scanner scanner = new Scanner(System.in);
	static Base64.Encoder enc = Base64.getEncoder();
    static Base64.Decoder dec = Base64.getDecoder();
	
	//constructor
	public Encoder() {
		
	}
	
	public static void encode() {
		System.out.println("Please enter the string to encode: ");
		String input = scanner.nextLine();
        String base64 = enc.encodeToString(input.getBytes());
        System.out.println("Encoded string is: " + base64);	
	}//encode()
	
	
	public static void decode() {
		System.out.println("Please enter the base64 to decode: ");
		String input = scanner.nextLine();
		String string = new String(dec.decode(input));
		System.out.println("Decoded string is: " + string);
	}//decode()

}
