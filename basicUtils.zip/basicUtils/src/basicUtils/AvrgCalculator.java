package basicUtils;

import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class AvrgCalculator {
	
	static Scanner scanner = new Scanner(System.in);

	public AvrgCalculator() {
		
	}
	
	public static void exe() {
		
		System.out.println("Please enter your name:");
		String name = scanner.nextLine();
		int loop=0;
		
		//checking the name only contains letters
		 if (name.matches("^[a-zA-Z ]+$")) {
             
         } else {
             System.out.println("\"**********Error: Please enter a valid name.\n");
             exe();
         }
		 
		
		//asking for data
		System.out.println("Please enter your grade:");
		String grade = scanner.nextLine();
		System.out.println("Please enter the number of signatures to enroll:");
		
		
		//checking the number of signatures to be an integer
		 try {
			
				loop = scanner.nextInt();
			
			
         } catch (InputMismatchException e) {
             System.out.println("**********Error0: Please enter a valid number.\n");
             scanner.next();
             System.exit(1);
         }
		
		//arrays to storage signatures and scores
		String [] sgntrs = new String[loop];
		double [] scores = new double[loop];
		
		
		//storing data into arrays
		for(int i=0; i<(loop);i++) {
			System.out.println("Please enter the name of signature "+(i+1)+" :");
			sgntrs[i] =scanner.next();
			scanner.nextLine();//cleaning the buffer
			System.out.println("Please enter the score for "+sgntrs[i]+" :");
			scores[i]=val(scanner.nextLine());
		}
				
		
		//printing data
		System.out.println("-------------------------------------------------------------------");
		System.out.println("Student name: "+name +"\t Grade:"+grade);
		System.out.println("-------------------------------------------------------------------");
		
		IntStream.range(0, Math.min(sgntrs.length, scores.length))
		.mapToObj(i -> String.valueOf("\tSignature : "+sgntrs[i]) +"\t Grade "+ scores[i])
        .forEach(System.out::println);
		
		System.out.println("-------------------------------------------------------------------");
		
		double avrg = Arrays.stream(scores)
                .average()
                .orElse(0.0);


        System.out.printf("Final average: %.2f \t", avrg);
        System.out.printf("\t Status: %s",(avrg > 8.0)  ? "Passed with good level" : "Didn´t pass ");
        
        System.out.println("\n-------------------------------------------------------------------");
		
	}//exe()
	
	
	public static  double val(String input) {
		 
		 String Spaces = input.replace(" ", "");
		 double noSpaces =0.0;
		
		 		if(!Spaces.matches(".*[^0-9.].*")){
			        try {
			            // Convert to double
			            noSpaces = Double.parseDouble(Spaces);
			            
			            // Check if the number is within range
			            if (noSpaces >= -Double.MAX_VALUE && noSpaces <= Double.MAX_VALUE ) {
			            	
			            } 
			            else {
			                System.out.println("Number out of range.\n");
			                exe();
			            }
			        }
			        catch (NumberFormatException e) {
			            System.out.println("**********Error1: Please enter a valid number.\n");
			            exe();
			        }
			    } 
			    else {
			        System.out.println("**********Error2: Please enter a valid number.\n");
			        exe();
			        }
		        
		return noSpaces;
		
		}//val()

}// AvrgCalculator
