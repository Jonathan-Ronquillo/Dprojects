package com.springdata.jpaexercise.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.springdata.jpaexercise.entities.Product;

public interface ProductRepository extends JpaRepository<Product, Integer>{

	//public ProductRepository() {}
	boolean existsById(int id);
	boolean existsByName(String name);
	

	Optional<Product> findByName(String name);
	Optional<Product> findById(int id);
	

	@Query(value = "SELECT MAX(product_id) FROM products", nativeQuery = true)
	Integer lastId();

	@Query(value = "SELECT total_products_inventory FROM products WHERE name = :name ", nativeQuery = true)
	int lastInventoryStatus(@Param("name") String name);
	
	
	
	 List<Product> findAll();
	 
	 @Query(value = "SELECT * FROM products WHERE name = :name ", nativeQuery = true)
	 List<Product> productByName(@Param("name") String name);
	 
	 @Query(value = "SELECT * FROM products WHERE price = :price ", nativeQuery = true)
	 List<Product> productByPrice(@Param("price") double price);

}
