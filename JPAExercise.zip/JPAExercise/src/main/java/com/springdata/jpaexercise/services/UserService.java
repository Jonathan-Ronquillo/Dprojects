package com.springdata.jpaexercise.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springdata.jpaexercise.entities.User;
import com.springdata.jpaexercise.repositories.UserRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository repository;

    public String createUser() {
        User user = new User();

        String email = "pablo@gmail.com";

        user.setUser_id(6);
        user.setName("pablo");
        user.setLast_name("Ronquillo");
        user.setEmail(email);
        user.setBio("Deloitte trainee");
        user.setArea_of_interest("CBO-java");

        if (repository.existsByEmail(email)) {
            return "Usuario no creado, el correo ya existe";
        } else {
            repository.save(user);
            return "Usuario creado correctamente";
        }
    }//createUser()

    public String deleteUser() {
        if (repository.existsById(6)) {
            repository.deleteById(6);
            return "Usuario eliminado";
        }
        return "Usuario no eliminado";
    }//deleteUser()

    public String updateUser() {
        User user = repository.findById(1).orElse(null);

        if (user != null) {
            user.setArea_of_interest("new area");
            user.setEmail("scnd@gmail.com");
            repository.save(user);
            return "Registro actualizado";
        } else {
            return"Usuario no encontrado";
        }
    }//updateUser()

    public List<String> getAllUsers() {
        List<User> existingUsers = repository.findAll();
        
        List<String> resultList = new ArrayList<>();
        
        for (User user : existingUsers) {
        	
        	resultList.add(user.getName()+" "+user.getLast_name());
        }
		return resultList;
    }//getAllUsers()
    
    

    public List<String> searchUserByName(String name) {
        List<User> existingUsers = repository.userByName(name);

        List<String> resultList = new ArrayList<>();
        
        for (User user : existingUsers) {
        	resultList.add(user.getName()+" "+user.getLast_name());
        }
		return resultList;
    }//searchUserByName()
    
    

    public List<String> searchUserByEmail(String email) {
        List<User> existingUsers = repository.userByEmail(email);
        List<String> resultList = new ArrayList<>();
        
        for (User user : existingUsers) {
        	resultList.add(user.getName()+" "+user.getLast_name());
        }
        return resultList;
    }//searchUserByEmail()
    
}//serviceClass