package com.springdata.jpaexercise.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.springdata.jpaexercise.services.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping("/create")
    public void createProduct() {
        productService.createProduct();
    }

    @DeleteMapping("/delete")
    public void deleteProduct() {
        productService.deleteProduct();
    }

    @PutMapping("/update")
    public void updateProduct() {
        productService.updateProduct();
    }

    @GetMapping("/all")
    public void getAllProducts() {
        productService.allProducts();
    }

    @GetMapping("/searchByName")
    public void searchProductByName(@RequestParam String name) {
        productService.searchProductByName(name);
    }

    @GetMapping("/searchByPrice")
    public void searchProductByPrice(@RequestParam double price) {
        productService.searchProductByPrice(price);
    }
}
