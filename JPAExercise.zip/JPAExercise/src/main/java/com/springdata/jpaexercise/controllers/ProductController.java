package com.springdata.jpaexercise.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.springdata.jpaexercise.services.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;
    

    //POST
    @GetMapping("/create")
    public ResponseEntity<String> createProduct() {
        productService.createProduct();
        return ResponseEntity.ok(productService.createProduct());
    }

    @GetMapping("/delete")
    public ResponseEntity<String> deleteProduct() {
        productService.deleteProduct();
        return ResponseEntity.ok(productService.deleteProduct());
    }

    @GetMapping("/update")
    public ResponseEntity<String> updateProduct() {
        productService.updateProduct();
        return ResponseEntity.ok(productService.updateProduct());
    }

    @GetMapping("/all")
    public ResponseEntity<List<String>> getAllProducts() {
    	List<String> products =  productService.allProducts();
        return ResponseEntity.ok(products);
        
    }

    @GetMapping("/searchByName")
    public ResponseEntity<List<String>> searchProductByName(@RequestParam String name) {
    	List<String> products =productService.searchProductByName(name);
        return ResponseEntity.ok(products);
    }

    @GetMapping("/searchByPrice")
    public ResponseEntity<List<String>> searchProductByPrice(@RequestParam double price) {
    	List<String> products =productService.searchProductByPrice(price);
        return ResponseEntity.ok(products);
    }
    
    @GetMapping("/buy/{product_Id}/{user_Id}/{quantity}")
    public ResponseEntity<String> buyProduct(@PathVariable int product_Id,@PathVariable int user_Id, @PathVariable int quantity){
    	productService.buyProduct(product_Id, user_Id, quantity);
    	return ResponseEntity.ok(productService.buyProduct(product_Id, user_Id, quantity));
    }
}
