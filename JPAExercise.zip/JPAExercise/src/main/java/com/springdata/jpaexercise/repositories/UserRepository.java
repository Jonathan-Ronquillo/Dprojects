package com.springdata.jpaexercise.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.springdata.jpaexercise.entities.User;

public interface UserRepository extends JpaRepository<User, Integer>{

//	public UserRepository() {
//		// TODO Auto-generated constructor stub
//	}

	boolean existsByEmail(String email);
	
	 List<User> findAll();
	 
	 @Query(value = "SELECT * FROM users WHERE name = :name ", nativeQuery = true)
	 List<User> userByName(@Param("name") String name);
	 
	 @Query(value = "SELECT * FROM users WHERE email = :email ", nativeQuery = true)
	 List<User> userByEmail(@Param("email") String email);
}
