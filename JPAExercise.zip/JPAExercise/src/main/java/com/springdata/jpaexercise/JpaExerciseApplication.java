package com.springdata.jpaexercise;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.springdata.jpaexercise.entities.Product;
import com.springdata.jpaexercise.entities.User;
import com.springdata.jpaexercise.repositories.ProductRepository;
import com.springdata.jpaexercise.repositories.UserRepository;

@SpringBootApplication
@ComponentScan(basePackages = {"com.springdata.jpaexercise.repositories","com.springdata.jpaexercise.entities", "com.springdata.jpaexercise.services","com.springdata.jpaexercise.controllers" })
public class JpaExerciseApplication  implements CommandLineRunner {

	@Autowired
	private UserRepository repository;
	@Autowired
	private ProductRepository prepository;
	
	public static void main(String[] args) {
		SpringApplication.run(JpaExerciseApplication.class, args);
	}//main
	
	@Override
	public void run(String... args) throws Exception {
		
		
		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		System.out.println("\n\n\n");
		
		
		//createUser();
		//DeleteUser();
		//UpdateUser();
		//CreateProduct();
		//DeleteProduct();
		//UpdateProduct();
		//AllUsers();
		//AllProducts();
		//SearchUserByName();
		//SearchUserByEmail();
		//SearchProductByName();
		//SearchProductByPrice();
		
		System.out.println("\n\n\n");
		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
	}
	
	private  void createUser() { //(@Autowired UserRepository userRepository)
		User user = new User();
		
		String email="E@gmail.com";

		user.setUser_id(1);
		user.setName("tatan2");
		user.setLast_name("Ronquillo");
		user.setEmail(email);
		user.setBio("Deloitte trainee");
		user.setArea_of_interest("CBO-java");
		
		if (repository.existsByEmail(email)) {
		    System.out.println("El correo ya existe");		    
			
		} else 
		{
			System.out.println("registro agregado");
			repository.save(user);
		}
	}
	
	private void DeleteUser() {
		if(repository.existsById(1)) {
		repository.deleteById(1);
		}
	}// DeleteUser()
	
	private void UpdateUser() {
		User user = repository.findById(1).get();
		user.setArea_of_interest("marketing");
		user.setEmail("newmail@gmail.com");
		System.out.println("Registro actualizado");
		repository.save(user);
	}//UpdateUser()
	
	private void AllUsers() {
		
		 List<User> existingUsers = repository.findAll();

	        for (User user : existingUsers) {
	            System.out.println("Nombre del usuario: " + user.getName() +" "+ user.getLast_name());
	        }
	}//AllUsers()
		
	private void SearchUserByName() {
		String name="Alan";
		
		 List<User> existingUsers = repository.userByName(name);

	        for (User user : existingUsers) {
	            System.out.println("Usuario encontrado: " + user.getName()+" "+ user.getLast_name());
	        }
	}//SearchUserByName()

	private void SearchUserByEmail() {
		String email="Alan@gmail.com";
		
		 List<User> existingUsers = repository.userByEmail(email);

	        for (User user : existingUsers) {
	        	System.out.println("Usuario encontrado: " + user.getName()+" "+ user.getLast_name());
	        }
	}//SearchUserByEmail()
	
	private void CreateProduct(){
		Product product = new Product();
		Integer lastID ;
		
		
		if(prepository.lastId()!=null) {
			lastID = prepository.lastId();
		}
		else {
			lastID =0;
		}
				
		
		String name= "Huawei3";
		
		if (prepository.existsByName(name)) {
			
			Product existingProduct = prepository.findByName(name).orElse(new Product());
			existingProduct.setTotal_products_inventory(prepository.lastInventoryStatus(name) + 1);

		    System.out.println("El producto ya existe, se agregó una unidad al inventario");	

		    prepository.save(existingProduct);
			
		} else 
		{
			product.setProduct_id(lastID +1);
			product.setName(name);
			product.setDescription("128 gb");
			product.setPrice(300.00);
			product.setStatus(true);
			product.setTotal_products_inventory(1);
			System.out.println("producto agregado");
			prepository.save(product);
		}			
	}//CreateProduct()

	private void DeleteProduct() {
		
		int id =3;
		
		if(prepository.existsById(id)) {
			
			Product existingProduct = prepository.findById(id).orElse(new Product());
			existingProduct.setStatus(false);

		    System.out.println("Producto eliminado");	

		    prepository.save(existingProduct);
			
		}else 
		{
			System.out.println("El producto que buscas no existe");
			}
	}// DeleteProduct()

	private void UpdateProduct() {
		int id=2; 
		
		int newTotalProductsInventory=5;
		double newPrice=500 ;
		String newDescription="version 5 ";
		
		Product product = prepository.findById(id).get();
		
		product.setPrice(newPrice);
		product.setDescription(newDescription);
		//product IMAGE
		product.setTotal_products_inventory(newTotalProductsInventory);
		
		System.out.println("Registro actualizado");
		prepository.save(product);
	}//UpdateProduct()

	
	private void AllProducts() {
		
		 List<Product> existingProducts = prepository.findAll();

	        for (Product product : existingProducts) {
	            System.out.println("Nombre del producto: " + product.getName() );
	        }
	}//AllProducts()


	

	private void SearchProductByName() {
		String name="Huawei";
		
		 List<Product> existingProduct = prepository.productByName(name);

	        for (Product product : existingProduct) {
	            System.out.println("Producto encontrado: " + product.getName());
	        }
	}//SearchProductByName()
	
	private void SearchProductByPrice() {
		double price=300;
		
		 List<Product> existingProduct = prepository.productByPrice(price);

	        for (Product product : existingProduct) {
	            System.out.println("Producto encontrado: " + product.getName());
	        }
	}//SearchProductByPrice()
}//class
