package com.springdata.jpaexercise.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.springdata.jpaexercise.entities.WishList;

public interface WishListRepository extends JpaRepository<WishList, Integer>{
	
	
	boolean existsById(int id);

	Optional<WishList> findById(int id);
	
	Optional<WishList> findByUserIdAndProductId(int user_Id, int product_Id);
	
	void deleteAllByUserId(int userId);
	
	@Query(value = "SELECT MAX(wish_id) FROM wishlist", nativeQuery = true)
	Integer lastId();
	
	@Query(value = "SELECT * FROM wishlist WHERE user_id = :userId ", nativeQuery = true)
	 List<WishList> wishlistById(@Param("userId") int userId);
	
	
	
}
