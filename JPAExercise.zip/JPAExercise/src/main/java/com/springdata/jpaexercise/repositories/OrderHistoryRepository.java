package com.springdata.jpaexercise.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.springdata.jpaexercise.entities.OrderHistory;

public interface OrderHistoryRepository  extends JpaRepository<OrderHistory, Integer>{

	
	
	@Query(value = "SELECT MAX(order_id) FROM order_history", nativeQuery = true)
	Integer lastId();
}
