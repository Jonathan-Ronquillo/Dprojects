package com.springdata.jpaexercise.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springdata.jpaexercise.services.WishListService;

@RestController
@RequestMapping("/wishlist")
public class WishlistController {
	
	@Autowired
	private WishListService wishService;

	@GetMapping("/add/{productId}/{userId}")
    public String addToWishlist(@PathVariable int productId, @PathVariable int userId) {
        wishService.addToWishList( productId,  userId);
        return "Successfully added to your wishlist ";
    }
	
	@GetMapping("/watch/{userId}")
    public ResponseEntity<List<String>> watchWishlist(@PathVariable int userId) {
        List<String> wishlist = wishService.watchWishlist(userId);
        return ResponseEntity.ok(wishlist);
    }

	
	@GetMapping("/deleteProduct/{productId}/{userId}")
	public ResponseEntity<String> deleteFromWishlist(@PathVariable int productId, @PathVariable int userId) {
	    wishService.deleteProductFromWishlist(userId, productId);
	    return ResponseEntity.ok("Successfully deleted from your wishlist");
	}
	
	@GetMapping("/deleteWishlist/{userId}")
	public ResponseEntity<String> deleteByUserId(@PathVariable int userId) {
	    wishService.deleteWishList(userId);
	    return ResponseEntity.ok( userId+ " user has successfully deleted his wishlist" );
	}
	
}
