package com.springdata.jpaexercise.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity 
@Table (name = "Products")
public class Product {

	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	//public Product() {}
	private int product_id;
	private String name;
	private double price;
//	private image image;
	private String description;
	private int total_products_inventory;
	private boolean status;
	
	
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getTotal_products_inventory() {
		return total_products_inventory;
	}
	public void setTotal_products_inventory(int total_products_inventory) {
		this.total_products_inventory = total_products_inventory;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	
	
	

}
