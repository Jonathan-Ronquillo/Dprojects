package com.springdata.jpaexercise.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springdata.jpaexercise.entities.Product;
import com.springdata.jpaexercise.entities.User;
import com.springdata.jpaexercise.entities.WishList;
import com.springdata.jpaexercise.repositories.WishListRepository;

import jakarta.transaction.Transactional;

@Service
public class WishListService {
	
	@Autowired
	private WishListRepository wishRepo;
	
	@Autowired
	private UserService userService;  
	
	@Autowired 
	private ProductService productService;

	
	public String addToWishList(int productId, int userId) {
		
		 Product product = productService.getProductById(productId);
	     User user = userService.getUserById(userId);
	     WishList wishList = new WishList();
	     //WishList wishList = wishRepo.findById(wishlistId).orElse(new WishList());
	     Integer lastID;
	     
	     if (wishRepo.lastId() != null) {
	            lastID = wishRepo.lastId();
	        } else {
	            lastID = 0;
	        }
	     
	        
	        wishList.setProduct_id(product.getProduct_id());
	        wishList.setUser_id(user.getUser_id());
	        wishList.setWish_id(lastID+1);

	        wishRepo.save(wishList);
	        
		return "Successfully added to your wishlist ";
	}//addToWishList -------------------------------
	
	public List<String> watchWishlist(int id) {
		
        List<WishList> userWishlist = wishRepo.wishlistById(id);
        
        List<String> resultList = new ArrayList<>();
        
        
        for (WishList item : userWishlist) {
        	resultList.add("producto: "+ item.getProduct_id());
        }
        return resultList;
    }// watchWishlist -------------------------------
	
	
	public String deleteProductFromWishlist(int user_Id, int product_Id) {
		
			Optional<WishList> wishlistOptional = wishRepo.findByUserIdAndProductId(user_Id, product_Id);
			
			if (wishlistOptional.isPresent()) {
				
		        wishRepo.delete(wishlistOptional.get());
		        return "Successfully deleted from your wishlist";
		        
		    } else {
		    	
		        return " The product with ID: " + product_Id + " doesn't exist in your wishlist";
		    }
			
		}//deleteProductFromWishlist() -------------------------------
	
	@Transactional
	public void deleteWishList(int userId) {
	    wishRepo.deleteAllByUserId(userId);
	}//deleteWishList() -------------------------------
}
