package com.springdata.jpaexercise.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springdata.jpaexercise.entities.Product;
import com.springdata.jpaexercise.repositories.ProductRepository;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

@Service
public class ProductService {

    @Autowired
    private ProductRepository prepository;

    public String createProduct() {
        Product product = new Product();
        Integer lastID;
        String imagePath = "C:\\Users\\jronquillorazo\\Pictures\\thumbsup.png";

        if (prepository.lastId() != null) {
            lastID = prepository.lastId();
        } else {
            lastID = 0;
        }

        String name = "HuaweiConImagen";

        if (prepository.existsByName(name)) {
            Product existingProduct = prepository.findByName(name).orElse(new Product());
            existingProduct.setTotal_products_inventory(prepository.lastInventoryStatus(name) + 1);

            prepository.save(existingProduct);
            
            return "El producto ya existe, se agregó una unidad al inventario";

        } else {
            product.setProduct_id(lastID + 1);
            product.setName(name);
            product.setDescription("128 gb");
            product.setPrice(300.00);
            product.setStatus(true);
            product.setTotal_products_inventory(1);
           // prepository.save(product);
            
            try {
                byte[] bytesImagen = Files.readAllBytes(new File(imagePath).toPath());
                product.setImage(bytesImagen);
            } catch (Exception e) {
                e.printStackTrace();
            }
            prepository.save(product);
            return "Producto creado correctamente";
        }
    }

    public String deleteProduct() {
        int id = 3;

        if (prepository.existsById(id)) {
            Product existingProduct = prepository.findById(id).orElse(new Product());
            existingProduct.setStatus(false);
            prepository.save(existingProduct);
            return "Producto eliminado";

        } else {
            return "El producto que buscas no existe";
        }
    }

    public String updateProduct() {
        int id = 2;

        int newTotalProductsInventory = 5;
        double newPrice = 500;
        String newDescription = "versión 5";

        Product product = prepository.findById(id).orElse(new Product());

        product.setPrice(newPrice);
        product.setDescription(newDescription);
        // product IMAGE
        product.setTotal_products_inventory(newTotalProductsInventory);
        prepository.save(product);
        return "Producto actualizado";
        
    }

    public List<String> allProducts() {
        List<Product> existingProducts = prepository.findAll();
        List<String> resultList = new ArrayList<>();
        
        for (Product product : existingProducts) {
        	resultList.add(product.getName());
        }
        return resultList;
    }

    public List<String> searchProductByName(String name) {
        List<Product> existingProducts = prepository.productByName(name);
        List<String> resultList = new ArrayList<>();

        for (Product product : existingProducts) {
            resultList.add("Producto encontrado: "+product.getName());
        }
        return resultList;
    }

    public List<String> searchProductByPrice(double price) {
        List<Product> existingProducts = prepository.productByPrice(price);
        List<String> resultList = new ArrayList<>();

        for (Product product : existingProducts) {
        	resultList.add("Producto encontrado: "+product.getName());
        }
        return resultList;
    }
}

