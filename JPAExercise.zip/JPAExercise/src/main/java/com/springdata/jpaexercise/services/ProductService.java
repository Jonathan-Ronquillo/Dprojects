package com.springdata.jpaexercise.services;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springdata.jpaexercise.entities.OrderHistory;
import com.springdata.jpaexercise.entities.Product;
import com.springdata.jpaexercise.repositories.OrderHistoryRepository;
import com.springdata.jpaexercise.repositories.ProductRepository;

import java.io.File;
import java.nio.file.Files;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
public class ProductService {

    @Autowired
    private ProductRepository prepository;
    
    @Autowired
    private OrderHistoryRepository orderRepository;
    

    public String createProduct() {
        Product product = new Product();
        Integer lastID;
        String imagePath = "C:\\Users\\jronquillorazo\\Pictures\\thumbsup.png";

        if (prepository.lastId() != null) {
            lastID = prepository.lastId();
        } else {
            lastID = 0;
        }

        String name = "xiaomi";

        if (prepository.existsByName(name)) {
            Product existingProduct = prepository.findByName(name).orElse(new Product());
            int currentInventory = prepository.lastInventoryStatus(name);
            int incrementInventory= 1;
            
            existingProduct.setTotal_products_inventory(incrementInventory + currentInventory);

            prepository.save(existingProduct);
            
            return "El producto ya existe, se agregó una unidad al inventario " + currentInventory;

        } else {
            product.setProduct_id(lastID + 1);
            product.setName(name);
            product.setDescription("128 gb");
            product.setPrice(300.00);
            product.setStatus(true);
            product.setTotal_products_inventory(1);
           // prepository.save(product);
            
            try {
                byte[] bytesImagen = Files.readAllBytes(new File(imagePath).toPath());
                product.setImage(bytesImagen);
            } catch (Exception e) {
                e.printStackTrace();
            }
            prepository.save(product);
            return "Producto creado correctamente";
        }
    }

    public String deleteProduct() {
        int id = 3;

        if (prepository.existsById(id)) {
            Product existingProduct = prepository.findById(id).orElse(new Product());
            existingProduct.setStatus(false);
            prepository.save(existingProduct);
            return "Producto eliminado";

        } else {
            return "El producto que buscas no existe";
        }
    }

    public String updateProduct() {
        int id = 2;

        int newTotalProductsInventory = 5;
        double newPrice = 500;
        String newDescription = "versión 5";

        Product product = prepository.findById(id).orElse(new Product());

        product.setPrice(newPrice);
        product.setDescription(newDescription);
        // product IMAGE
        product.setTotal_products_inventory(newTotalProductsInventory);
        prepository.save(product);
        return "Producto actualizado";
        
    }

    public List<String> allProducts() {
        List<Product> existingProducts = prepository.findAll();
        List<String> resultList = new ArrayList<>();
        
        for (Product product : existingProducts) {
        	resultList.add(product.getName());
        }
        return resultList;
    }

    public List<String> searchProductByName(String name) {
        List<Product> existingProducts = prepository.productByName(name);
        List<String> resultList = new ArrayList<>();

        for (Product product : existingProducts) {
            resultList.add("Producto encontrado: "+product.getName());
        }
        return resultList;
    }

    public List<String> searchProductByPrice(double price) {
        List<Product> existingProducts = prepository.productByPrice(price);
        List<String> resultList = new ArrayList<>();

        for (Product product : existingProducts) {
        	resultList.add("Producto encontrado: "+product.getName());
        }
        return resultList;
    }
    
    public Product getProductById(int productId) {
        return prepository.findById(productId).orElse(null);
    }
    
    public String buyProduct(int product_Id, int user_Id, int quantity) {
    	
    	 OrderHistory newOrderHistory = new OrderHistory();
    	 Product existingProduct = prepository.findById(product_Id).orElse(new Product());
    	     	    	 
	     LocalDate currentDate = LocalDate.now();
	     DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yy-MM-dd");
	     String Date = currentDate.format(formatter);
	     
	     Integer lastID;
	     
	     if (orderRepository.lastId() != null) {
	            lastID = orderRepository.lastId();
	        } else {
	            lastID = 0;
	        }
             
    	 if (prepository.existsById(product_Id)) {  
    		 
    		 if(existingProduct.getTotal_products_inventory() > 0) {
    		 
	             if(existingProduct.getTotal_products_inventory() >= quantity) {
	            	  
	            	 int newInventory = existingProduct.getTotal_products_inventory() - quantity;
	            	 existingProduct.setTotal_products_inventory(newInventory);
	            	 
	            	 newOrderHistory.setOrderId(lastID +1 );
	            	 newOrderHistory.setOrderDate(Date);
	            	 newOrderHistory.setProductId(product_Id);
	            	 newOrderHistory.setUserId(user_Id);
	            	 
	            	 orderRepository.save(newOrderHistory);
	             }
	             else {
	            	 return "There is no enough product in stock";
	             }
    	 	 }
             else {
            	 return "There is no more inventory for the product: " + product_Id;
             }
    	 }
         else {
             return "That product doesn´t exist";
         } 
    	
    	return "You have bought a product";
    }//buyProduct
}

