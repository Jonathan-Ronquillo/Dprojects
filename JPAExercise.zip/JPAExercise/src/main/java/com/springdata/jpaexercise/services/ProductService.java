package com.springdata.jpaexercise.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springdata.jpaexercise.entities.Product;
import com.springdata.jpaexercise.repositories.ProductRepository;

import java.util.List;

@Service
public class ProductService {

    @Autowired
    private ProductRepository prepository;

    public void createProduct() {
        Product product = new Product();
        Integer lastID;

        if (prepository.lastId() != null) {
            lastID = prepository.lastId();
        } else {
            lastID = 0;
        }

        String name = "Huawei3";

        if (prepository.existsByName(name)) {
            Product existingProduct = prepository.findByName(name).orElse(new Product());
            existingProduct.setTotal_products_inventory(prepository.lastInventoryStatus(name) + 1);

            System.out.println("El producto ya existe, se agregó una unidad al inventario");

            prepository.save(existingProduct);

        } else {
            product.setProduct_id(lastID + 1);
            product.setName(name);
            product.setDescription("128 gb");
            product.setPrice(300.00);
            product.setStatus(true);
            product.setTotal_products_inventory(1);
            System.out.println("Producto agregado");
            prepository.save(product);
        }
    }

    public void deleteProduct() {
        int id = 3;

        if (prepository.existsById(id)) {
            Product existingProduct = prepository.findById(id).orElse(new Product());
            existingProduct.setStatus(false);

            System.out.println("Producto eliminado");

            prepository.save(existingProduct);

        } else {
            System.out.println("El producto que buscas no existe");
        }
    }

    public void updateProduct() {
        int id = 2;

        int newTotalProductsInventory = 5;
        double newPrice = 500;
        String newDescription = "versión 5";

        Product product = prepository.findById(id).orElse(new Product());

        product.setPrice(newPrice);
        product.setDescription(newDescription);
        // product IMAGE
        product.setTotal_products_inventory(newTotalProductsInventory);

        System.out.println("Registro actualizado");
        prepository.save(product);
    }

    public void allProducts() {
        List<Product> existingProducts = prepository.findAll();

        for (Product product : existingProducts) {
            System.out.println("Nombre del producto: " + product.getName());
        }
    }

    public void searchProductByName(String name) {
        List<Product> existingProducts = prepository.productByName(name);

        for (Product product : existingProducts) {
            System.out.println("Producto encontrado: " + product.getName());
        }
    }

    public void searchProductByPrice(double price) {
        List<Product> existingProducts = prepository.productByPrice(price);

        for (Product product : existingProducts) {
            System.out.println("Producto encontrado: " + product.getName());
        }
    }
}

