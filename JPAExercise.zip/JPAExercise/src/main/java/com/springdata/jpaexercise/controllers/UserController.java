package com.springdata.jpaexercise.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.springdata.jpaexercise.services.UserService;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/create")
    public ResponseEntity<String> createUser() {
        userService.createUser();
        return ResponseEntity.ok(userService.createUser());
    }

    @GetMapping("/delete")
    public ResponseEntity<String> deleteUser() {
        userService.deleteUser();
        return ResponseEntity.ok(userService.deleteUser());
    }

    @GetMapping("/update")
    public ResponseEntity<String> updateUser() {
        userService.updateUser();
        return ResponseEntity.ok(userService.updateUser());
    }

    @GetMapping("/all")
    public ResponseEntity<List<String>> getAllUsers() {
        List<String> users = userService.getAllUsers();
        return ResponseEntity.ok(users);
    }

    @GetMapping("/searchByName")
    public ResponseEntity<List<String>> searchUserByName(@RequestParam String name) {
        List<String> users = userService.searchUserByName(name);
        return ResponseEntity.ok(users);
    }

    @GetMapping("/searchByEmail")
    public ResponseEntity<List<String>> searchUserByEmail(@RequestParam String email) {
        List<String> users = userService.searchUserByEmail(email);
        return ResponseEntity.ok(users);
    }
}