package com.springdata.jpaexercise;


import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.springdata.jpaexercise.entities.Product;
import com.springdata.jpaexercise.entities.User;
import com.springdata.jpaexercise.repositories.ProductRepository;
import com.springdata.jpaexercise.repositories.UserRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
class JpaExerciseApplicationTests {
	
	@Autowired
	UserRepository repository;
	@Autowired
	ProductRepository prepository;
	
	@Test
	void contextLoads() {
	}
	
	@Test
	public void testCreateUser()
	{
		User user = new User();

		user.setUser_id(2);
		user.setName("Eduardo");
		user.setLast_name("Ronquillo");
		user.setEmail("Edu@gmail.com");
		user.setBio("Deloitte trainee");
		user.setArea_of_interest("CBO-java");
		
		if (repository.existsByEmail("none@gmail.com")) {
		    System.out.println("El correo ya existe");		    
			
		} else 
		{
			System.out.println("registro agregado");
			repository.save(user);
		}
		
	}//testCreate()

	@Test
	public void testDeleteUser() {
		if(repository.existsById(1)) {
		repository.deleteById(1);
		}//if
	}// testDelete()
	
	@Test
	public void testUpdateUser() {
		User user = repository.findById(1).get();
		user.setArea_of_interest("marketing");
		user.setEmail("newmail@gmail.com");
		System.out.println("Registro actualizado");
		repository.save(user);
	}
	
	
	@Test
	public void testCreateProduct()
	{
		Product product = new Product();
		Integer lastID ;
		
		
		if(prepository.lastId()!=null) {
			lastID = prepository.lastId();
		}
		else {
			lastID =0;
		}
				
		
		String name= "Huawei2";
		
		if (prepository.existsByName(name)) {
			
			Product existingProduct = prepository.findByName(name).orElse(new Product());
			existingProduct.setTotal_products_inventory(prepository.lastInventoryStatus(name) + 1);

		    System.out.println("El producto ya existe, se agregó una unidad al inventario");	

		    prepository.save(existingProduct);
			
		} else 
		{
			product.setProduct_id(lastID +1);
			product.setName(name);
			product.setDescription("128 gb");
			product.setPrice(300.00);
			product.setStatus(true);
			product.setTotal_products_inventory(1);
			System.out.println("producto agregado");
			prepository.save(product);
		}			
	}//testCreate()
	
	
	
	@Test
	public void testDeleteProduct() {
		int id = 2;
		if(prepository.existsById(id)) {
			
			Product existingProduct = prepository.findById(id).orElse(new Product());
			existingProduct.setStatus(false);

		    System.out.println("El producto ya existe, se agregó una unidad al inventario");	

		    prepository.save(existingProduct);
			
		}else 
		{
			System.out.println("El producto que buscas no existe");
			}
	}// testDelete()
	
	@Test
	public void testUpdateProduct() {
		int id=2; 
		int newTotalProductsInventory=5;
		double newPrice=500 ;
		String newDescription="version 2 ";
		
		Product product = prepository.findById(id).get();
		
		product.setPrice(newPrice);
		product.setDescription(newDescription);
		//product IMAGE
		product.setTotal_products_inventory(newTotalProductsInventory);
		
		System.out.println("Registro actualizado");
		prepository.save(product);
	}
	
	
	@Test
	public void testAllUsers() {
		
		 List<User> existingUsers = repository.findAll();

	        for (User user : existingUsers) {
	            System.out.println("Nombre del usuario: " + user.getName() +" "+ user.getLast_name());
	        }
	}
	
	
	@Test
	public void testAllProducts() {
		
		 List<Product> existingProducts = prepository.findAll();

	        for (Product product : existingProducts) {
	            System.out.println("Nombre del producto: " + product.getName() );
	        }
	}
	
	@Test
	public void testSearchUserByName() {
		String name="Alan";
		
		 List<User> existingUsers = repository.userByName(name);

	        for (User user : existingUsers) {
	            System.out.println("Usuario encontrado: " + user.getName()+" "+ user.getLast_name());
	        }
	}
	
	@Test
	public void testSearchUserByEmail() {
		String email="Alan@gmail.com";
		
		 List<User> existingUsers = repository.userByEmail(email);

	        for (User user : existingUsers) {
	        	System.out.println("Usuario encontrado: " + user.getName()+" "+ user.getLast_name());
	        }
	}
	
	@Test
	public void testSearchProductByName() {
		String name="Huawei";
		
		 List<Product> existingProduct = prepository.productByName(name);

	        for (Product product : existingProduct) {
	            System.out.println("Producto encontrado: " + product.getName());
	        }
	}
	
	@Test
	public void testSearchProductByPrice() {
		double price=300;
		
		 List<Product> existingProduct = prepository.productByPrice(price);

	        for (Product product : existingProduct) {
	            System.out.println("Producto encontrado: " + product.getName());
	        }
	}
	
	
}//class
